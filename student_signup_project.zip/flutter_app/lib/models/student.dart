class Student {
  final int? id;
  final String fullName;
  final String email;
  final String phoneNumber;
  final String rollNumber;
  final String department;
  final int semester;
  final DateTime dateOfBirth;
  final String gender;
  final String? address;
  final DateTime? createdAt;

  Student({
    this.id,
    required this.fullName,
    required this.email,
    required this.phoneNumber,
    required this.rollNumber,
    required this.department,
    required this.semester,
    required this.dateOfBirth,
    required this.gender,
    this.address,
    this.createdAt,
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id'],
      fullName: json['fullName'] ?? '',
      email: json['email'] ?? '',
      phoneNumber: json['phoneNumber'] ?? '',
      rollNumber: json['rollNumber'] ?? '',
      department: json['department'] ?? '',
      semester: json['semester'] ?? 0,
      dateOfBirth: DateTime.tryParse(json['dateOfBirth'] ?? '') ?? DateTime.now(),
      gender: json['gender'] ?? '',
      address: json['address'],
      createdAt: json['createdAt'] != null ? DateTime.tryParse(json['createdAt']) : null,
    );
  }

  // Used for signup submission (includes password)
  Map<String, dynamic> toSignupJson(String password) {
    return {
      'fullName': fullName,
      'email': email,
      'password': password,
      'phoneNumber': phoneNumber,
      'rollNumber': rollNumber,
      'department': department,
      'semester': semester,
      'dateOfBirth': dateOfBirth.toIso8601String(),
      'gender': gender,
      'address': address,
    };
  }
}
