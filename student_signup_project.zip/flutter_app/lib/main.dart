import 'package:flutter/material.dart';
import 'screens/signup_screen.dart';
import 'theme.dart';

void main() {
  runApp(const StudentApp());
}

class StudentApp extends StatelessWidget {
  const StudentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Signup App',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const SignupScreen(),
    );
  }
}
