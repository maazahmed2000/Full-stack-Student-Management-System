import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/student.dart';

class ApiService {
  // NOTE: change this to your machine's IP / deployed API URL.
  // - Android emulator -> use 10.0.2.2 instead of localhost
  // - iOS simulator    -> localhost works fine
  // - Real device      -> use your PC's LAN IP, e.g. http://192.168.1.5:5000
  static const String baseUrl = 'http://10.0.2.2:5000/api';

  static Future<Map<String, dynamic>> signup(Student student, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/students/signup'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(student.toSignupJson(password)),
    );

    if (response.statusCode == 201) {
      return {'success': true, 'data': jsonDecode(response.body)};
    } else {
      final body = jsonDecode(response.body);
      return {'success': false, 'message': body['message'] ?? 'Signup failed'};
    }
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/students/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return {'success': true, 'data': jsonDecode(response.body)};
    } else {
      final body = jsonDecode(response.body);
      return {'success': false, 'message': body['message'] ?? 'Login failed'};
    }
  }

  static Future<List<Student>> getAllStudents() async {
    final response = await http.get(Uri.parse('$baseUrl/students'));

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((json) => Student.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load students');
    }
  }

  static Future<bool> deleteStudent(int id) async {
    final response = await http.delete(Uri.parse('$baseUrl/students/$id'));
    return response.statusCode == 204;
  }
}
