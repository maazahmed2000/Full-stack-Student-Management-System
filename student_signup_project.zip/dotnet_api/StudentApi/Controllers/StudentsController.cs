using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentApi.Data;
using StudentApi.DTOs;
using StudentApi.Models;

namespace StudentApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StudentsController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/students/signup
        [HttpPost("signup")]
        public async Task<ActionResult<StudentResponseDto>> Signup(StudentSignupDto dto)
        {
            if (await _context.Students.AnyAsync(s => s.Email == dto.Email))
                return Conflict(new { message = "Email already registered." });

            if (await _context.Students.AnyAsync(s => s.RollNumber == dto.RollNumber))
                return Conflict(new { message = "Roll number already exists." });

            var student = new Student
            {
                FullName = dto.FullName,
                Email = dto.Email,
                Password = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                PhoneNumber = dto.PhoneNumber,
                RollNumber = dto.RollNumber,
                Department = dto.Department,
                Semester = dto.Semester,
                DateOfBirth = dto.DateOfBirth,
                Gender = dto.Gender,
                Address = dto.Address,
                CreatedAt = DateTime.UtcNow
            };

            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = student.Id }, ToResponseDto(student));
        }

        // POST: api/students/login
        [HttpPost("login")]
        public async Task<ActionResult<StudentResponseDto>> Login(LoginDto dto)
        {
            var student = await _context.Students.FirstOrDefaultAsync(s => s.Email == dto.Email);

            if (student == null || !BCrypt.Net.BCrypt.Verify(dto.Password, student.Password))
                return Unauthorized(new { message = "Invalid email or password." });

            return Ok(ToResponseDto(student));
        }

        // GET: api/students
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentResponseDto>>> GetAll()
        {
            var students = await _context.Students
                .OrderByDescending(s => s.CreatedAt)
                .ToListAsync();

            return Ok(students.Select(ToResponseDto));
        }

        // GET: api/students/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentResponseDto>> GetById(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            return Ok(ToResponseDto(student));
        }

        // PUT: api/students/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, StudentSignupDto dto)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            student.FullName = dto.FullName;
            student.PhoneNumber = dto.PhoneNumber;
            student.Department = dto.Department;
            student.Semester = dto.Semester;
            student.DateOfBirth = dto.DateOfBirth;
            student.Gender = dto.Gender;
            student.Address = dto.Address;

            await _context.SaveChangesAsync();
            return Ok(ToResponseDto(student));
        }

        // DELETE: api/students/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            _context.Students.Remove(student);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private static StudentResponseDto ToResponseDto(Student s) => new()
        {
            Id = s.Id,
            FullName = s.FullName,
            Email = s.Email,
            PhoneNumber = s.PhoneNumber,
            RollNumber = s.RollNumber,
            Department = s.Department,
            Semester = s.Semester,
            DateOfBirth = s.DateOfBirth,
            Gender = s.Gender,
            Address = s.Address,
            CreatedAt = s.CreatedAt
        };
    }
}
